package com.xxl.conf.example.core.constant;

/**
 * 测试用,可删除
 */
public class Configuration {

	public String paramByXml;

	public void setParamByXml(String paramByXml) {
		this.paramByXml = paramByXml;
	}

}
