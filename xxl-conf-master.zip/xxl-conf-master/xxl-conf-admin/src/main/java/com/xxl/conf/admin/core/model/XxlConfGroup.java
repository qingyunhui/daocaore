package com.xxl.conf.admin.core.model;

/**
 * Created by xuxueli on 16/10/8.
 */
public class XxlConfGroup {
    private String groupName;
    private String groupTitle;

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupTitle() {
        return groupTitle;
    }

    public void setGroupTitle(String groupTitle) {
        this.groupTitle = groupTitle;
    }
}
