package me.veryyoung.qq.luckymoney.enums;

/**
 * Created by veryyoung on 2017/2/7.
 */

public enum PasswordStatus {
    CLOSE, SEND, DONOT_SEND
}
