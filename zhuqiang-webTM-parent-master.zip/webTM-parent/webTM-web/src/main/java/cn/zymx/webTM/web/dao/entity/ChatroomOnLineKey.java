package cn.zymx.webTM.web.dao.entity;

public class ChatroomOnLineKey {
    /** 聊天室id */
    private Long chatroomId;

    /** 用户id */
    private Long userId;

    /** 聊天室id */
    public Long getChatroomId() {
        return chatroomId;
    }

    public void setChatroomId(Long chatroomId) {
        this.chatroomId = chatroomId;
    }

    /** 用户id */
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}