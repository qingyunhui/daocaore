package cn.zymx.webTM.web.dao.entity;

import java.util.Date;

public class ChatroomOnLine extends ChatroomOnLineKey {
    /** 用户在线状态 */
    private Integer onLineStatus;

    /** 每个用户第一次进入聊天室就会生成一个token */
    private String token;

    private Long createById;

    private Date createByDate;

    private Long updateById;

    private Date updateByDate;

    /** 用户在线状态 */
    public Integer getOnLineStatus() {
        return onLineStatus;
    }

    public void setOnLineStatus(Integer onLineStatus) {
        this.onLineStatus = onLineStatus;
    }

    /** 每个用户第一次进入聊天室就会生成一个token */
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token == null ? null : token.trim();
    }

    public Long getCreateById() {
        return createById;
    }

    public void setCreateById(Long createById) {
        this.createById = createById;
    }

    public Date getCreateByDate() {
        return createByDate;
    }

    public void setCreateByDate(Date createByDate) {
        this.createByDate = createByDate;
    }

    public Long getUpdateById() {
        return updateById;
    }

    public void setUpdateById(Long updateById) {
        this.updateById = updateById;
    }

    public Date getUpdateByDate() {
        return updateByDate;
    }

    public void setUpdateByDate(Date updateByDate) {
        this.updateByDate = updateByDate;
    }
}