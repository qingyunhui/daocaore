package cn.zymx.webTM.web.controller;

import cn.zymx.webTM.web.services.ITestService;
import com.alibaba.fastjson.JSON;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.annotation.SubscribeMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;

@Controller
public class TestController{
	@Autowired
	private ITestService iTestService;

	@RequestMapping(value = "/test", produces = "application/json;;charset=utf-8")
	@ResponseBody
	public String test(HttpSession session) {
		session.setAttribute("WEBSOCKET_USERNAME","朱强");
		return JSON.toJSONString(iTestService.findAllUser());
	}

	//订阅/topic/greetings 地址，那么只要有人访问hello 就会发送给订阅了该地址的人员
	@MessageMapping("/hello")
	@SendTo("/topic/greetings")
	public String socket(String msg,HttpSession session){
		Object websocket_username = session.getAttribute("WEBSOCKET_USERNAME");
		System.out.printf("xxxxxxxxxxxxxxxxxxxx");
		return JSON.toJSONString(iTestService.findAllUser());
	}

	//访问
	@SubscribeMapping("/pull")
	public String pull(){
		System.out.printf("xxxxxxxxxxxxxxxxxxxx");
		return JSON.toJSONString(iTestService.findAllUser());
	}

}
