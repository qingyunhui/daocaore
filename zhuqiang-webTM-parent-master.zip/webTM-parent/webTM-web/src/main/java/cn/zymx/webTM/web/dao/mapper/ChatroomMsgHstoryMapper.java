package cn.zymx.webTM.web.dao.mapper;

import cn.zymx.webTM.web.dao.entity.ChatroomMsgHstory;
import cn.zymx.webTM.web.dao.entity.ChatroomMsgHstoryExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ChatroomMsgHstoryMapper {
    int countByExample(ChatroomMsgHstoryExample example);

    int deleteByExample(ChatroomMsgHstoryExample example);

    int insert(ChatroomMsgHstory record);

    int insertSelective(ChatroomMsgHstory record);

    List<ChatroomMsgHstory> selectByExample(ChatroomMsgHstoryExample example);

    int updateByExampleSelective(@Param("record") ChatroomMsgHstory record, @Param("example") ChatroomMsgHstoryExample example);

    int updateByExample(@Param("record") ChatroomMsgHstory record, @Param("example") ChatroomMsgHstoryExample example);
}