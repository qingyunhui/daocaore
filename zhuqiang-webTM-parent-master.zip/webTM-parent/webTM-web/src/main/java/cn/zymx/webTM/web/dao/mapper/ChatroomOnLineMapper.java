package cn.zymx.webTM.web.dao.mapper;

import cn.zymx.webTM.web.dao.entity.ChatroomOnLine;
import cn.zymx.webTM.web.dao.entity.ChatroomOnLineExample;
import cn.zymx.webTM.web.dao.entity.ChatroomOnLineKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ChatroomOnLineMapper {
    int countByExample(ChatroomOnLineExample example);

    int deleteByExample(ChatroomOnLineExample example);

    int deleteByPrimaryKey(ChatroomOnLineKey key);

    int insert(ChatroomOnLine record);

    int insertSelective(ChatroomOnLine record);

    List<ChatroomOnLine> selectByExample(ChatroomOnLineExample example);

    ChatroomOnLine selectByPrimaryKey(ChatroomOnLineKey key);

    int updateByExampleSelective(@Param("record") ChatroomOnLine record, @Param("example") ChatroomOnLineExample example);

    int updateByExample(@Param("record") ChatroomOnLine record, @Param("example") ChatroomOnLineExample example);

    int updateByPrimaryKeySelective(ChatroomOnLine record);

    int updateByPrimaryKey(ChatroomOnLine record);
}