package cn.zymx.webTM.web.dao.entity;

public class FriendListKey {
    /** 用户id */
    private Long userId;

    /** 好友id */
    private Long friendUserId;

    /** 用户id */
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /** 好友id */
    public Long getFriendUserId() {
        return friendUserId;
    }

    public void setFriendUserId(Long friendUserId) {
        this.friendUserId = friendUserId;
    }
}