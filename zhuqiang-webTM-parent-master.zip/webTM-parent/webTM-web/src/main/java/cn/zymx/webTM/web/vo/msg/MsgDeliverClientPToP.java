package cn.zymx.webTM.web.vo.msg;

/**
 * Created by zhuqiang on 2015/7/3 0003.
 */
public class MsgDeliverClientPToP extends MsgDeliverClient {
}
