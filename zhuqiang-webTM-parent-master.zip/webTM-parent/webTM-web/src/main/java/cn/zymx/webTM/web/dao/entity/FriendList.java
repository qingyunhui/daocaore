package cn.zymx.webTM.web.dao.entity;

import java.util.Date;

public class FriendList extends FriendListKey {
    private Long createById;

    private Date createByDate;

    private Long updateById;

    private Date updateByDate;

    public Long getCreateById() {
        return createById;
    }

    public void setCreateById(Long createById) {
        this.createById = createById;
    }

    public Date getCreateByDate() {
        return createByDate;
    }

    public void setCreateByDate(Date createByDate) {
        this.createByDate = createByDate;
    }

    public Long getUpdateById() {
        return updateById;
    }

    public void setUpdateById(Long updateById) {
        this.updateById = updateById;
    }

    public Date getUpdateByDate() {
        return updateByDate;
    }

    public void setUpdateByDate(Date updateByDate) {
        this.updateByDate = updateByDate;
    }
}