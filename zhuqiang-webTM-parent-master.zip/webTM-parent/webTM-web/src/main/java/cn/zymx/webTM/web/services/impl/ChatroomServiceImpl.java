package cn.zymx.webTM.web.services.impl;

import cn.zymx.webTM.web.services.IChatroomService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by zhuqiang on 2015/7/1 0001.
 * 聊天室服务
 */
@Service
@Transactional
public class ChatroomServiceImpl implements IChatroomService{
}
