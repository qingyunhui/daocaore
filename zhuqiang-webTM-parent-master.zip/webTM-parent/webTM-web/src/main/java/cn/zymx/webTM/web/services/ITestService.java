package cn.zymx.webTM.web.services;

import cn.zymx.webTM.web.dao.entity.User;

import java.util.List;

/**
 * Created by zhuqiang on 2015/6/21 0021.
 */
public interface ITestService {
    public List<User> findAllUser();
}
