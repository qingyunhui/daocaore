package cn.zymx.webTM.web.dao.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UserExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public UserExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andUserIdIsNull() {
            addCriterion("user_Id is null");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNotNull() {
            addCriterion("user_Id is not null");
            return (Criteria) this;
        }

        public Criteria andUserIdEqualTo(Long value) {
            addCriterion("user_Id =", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotEqualTo(Long value) {
            addCriterion("user_Id <>", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThan(Long value) {
            addCriterion("user_Id >", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("user_Id >=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThan(Long value) {
            addCriterion("user_Id <", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThanOrEqualTo(Long value) {
            addCriterion("user_Id <=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdIn(List<Long> values) {
            addCriterion("user_Id in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotIn(List<Long> values) {
            addCriterion("user_Id not in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdBetween(Long value1, Long value2) {
            addCriterion("user_Id between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotBetween(Long value1, Long value2) {
            addCriterion("user_Id not between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andEmailIsNull() {
            addCriterion("email is null");
            return (Criteria) this;
        }

        public Criteria andEmailIsNotNull() {
            addCriterion("email is not null");
            return (Criteria) this;
        }

        public Criteria andEmailEqualTo(String value) {
            addCriterion("email =", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotEqualTo(String value) {
            addCriterion("email <>", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailGreaterThan(String value) {
            addCriterion("email >", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailGreaterThanOrEqualTo(String value) {
            addCriterion("email >=", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLessThan(String value) {
            addCriterion("email <", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLessThanOrEqualTo(String value) {
            addCriterion("email <=", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLike(String value) {
            addCriterion("email like", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotLike(String value) {
            addCriterion("email not like", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailIn(List<String> values) {
            addCriterion("email in", values, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotIn(List<String> values) {
            addCriterion("email not in", values, "email");
            return (Criteria) this;
        }

        public Criteria andEmailBetween(String value1, String value2) {
            addCriterion("email between", value1, value2, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotBetween(String value1, String value2) {
            addCriterion("email not between", value1, value2, "email");
            return (Criteria) this;
        }

        public Criteria andNicknameIsNull() {
            addCriterion("nickname is null");
            return (Criteria) this;
        }

        public Criteria andNicknameIsNotNull() {
            addCriterion("nickname is not null");
            return (Criteria) this;
        }

        public Criteria andNicknameEqualTo(String value) {
            addCriterion("nickname =", value, "nickname");
            return (Criteria) this;
        }

        public Criteria andNicknameNotEqualTo(String value) {
            addCriterion("nickname <>", value, "nickname");
            return (Criteria) this;
        }

        public Criteria andNicknameGreaterThan(String value) {
            addCriterion("nickname >", value, "nickname");
            return (Criteria) this;
        }

        public Criteria andNicknameGreaterThanOrEqualTo(String value) {
            addCriterion("nickname >=", value, "nickname");
            return (Criteria) this;
        }

        public Criteria andNicknameLessThan(String value) {
            addCriterion("nickname <", value, "nickname");
            return (Criteria) this;
        }

        public Criteria andNicknameLessThanOrEqualTo(String value) {
            addCriterion("nickname <=", value, "nickname");
            return (Criteria) this;
        }

        public Criteria andNicknameLike(String value) {
            addCriterion("nickname like", value, "nickname");
            return (Criteria) this;
        }

        public Criteria andNicknameNotLike(String value) {
            addCriterion("nickname not like", value, "nickname");
            return (Criteria) this;
        }

        public Criteria andNicknameIn(List<String> values) {
            addCriterion("nickname in", values, "nickname");
            return (Criteria) this;
        }

        public Criteria andNicknameNotIn(List<String> values) {
            addCriterion("nickname not in", values, "nickname");
            return (Criteria) this;
        }

        public Criteria andNicknameBetween(String value1, String value2) {
            addCriterion("nickname between", value1, value2, "nickname");
            return (Criteria) this;
        }

        public Criteria andNicknameNotBetween(String value1, String value2) {
            addCriterion("nickname not between", value1, value2, "nickname");
            return (Criteria) this;
        }

        public Criteria andPasswordIsNull() {
            addCriterion("password is null");
            return (Criteria) this;
        }

        public Criteria andPasswordIsNotNull() {
            addCriterion("password is not null");
            return (Criteria) this;
        }

        public Criteria andPasswordEqualTo(String value) {
            addCriterion("password =", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordNotEqualTo(String value) {
            addCriterion("password <>", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordGreaterThan(String value) {
            addCriterion("password >", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordGreaterThanOrEqualTo(String value) {
            addCriterion("password >=", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordLessThan(String value) {
            addCriterion("password <", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordLessThanOrEqualTo(String value) {
            addCriterion("password <=", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordLike(String value) {
            addCriterion("password like", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordNotLike(String value) {
            addCriterion("password not like", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordIn(List<String> values) {
            addCriterion("password in", values, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordNotIn(List<String> values) {
            addCriterion("password not in", values, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordBetween(String value1, String value2) {
            addCriterion("password between", value1, value2, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordNotBetween(String value1, String value2) {
            addCriterion("password not between", value1, value2, "password");
            return (Criteria) this;
        }

        public Criteria andIconsIsNull() {
            addCriterion("Icons is null");
            return (Criteria) this;
        }

        public Criteria andIconsIsNotNull() {
            addCriterion("Icons is not null");
            return (Criteria) this;
        }

        public Criteria andIconsEqualTo(String value) {
            addCriterion("Icons =", value, "icons");
            return (Criteria) this;
        }

        public Criteria andIconsNotEqualTo(String value) {
            addCriterion("Icons <>", value, "icons");
            return (Criteria) this;
        }

        public Criteria andIconsGreaterThan(String value) {
            addCriterion("Icons >", value, "icons");
            return (Criteria) this;
        }

        public Criteria andIconsGreaterThanOrEqualTo(String value) {
            addCriterion("Icons >=", value, "icons");
            return (Criteria) this;
        }

        public Criteria andIconsLessThan(String value) {
            addCriterion("Icons <", value, "icons");
            return (Criteria) this;
        }

        public Criteria andIconsLessThanOrEqualTo(String value) {
            addCriterion("Icons <=", value, "icons");
            return (Criteria) this;
        }

        public Criteria andIconsLike(String value) {
            addCriterion("Icons like", value, "icons");
            return (Criteria) this;
        }

        public Criteria andIconsNotLike(String value) {
            addCriterion("Icons not like", value, "icons");
            return (Criteria) this;
        }

        public Criteria andIconsIn(List<String> values) {
            addCriterion("Icons in", values, "icons");
            return (Criteria) this;
        }

        public Criteria andIconsNotIn(List<String> values) {
            addCriterion("Icons not in", values, "icons");
            return (Criteria) this;
        }

        public Criteria andIconsBetween(String value1, String value2) {
            addCriterion("Icons between", value1, value2, "icons");
            return (Criteria) this;
        }

        public Criteria andIconsNotBetween(String value1, String value2) {
            addCriterion("Icons not between", value1, value2, "icons");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusIsNull() {
            addCriterion("on_Line_Status is null");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusIsNotNull() {
            addCriterion("on_Line_Status is not null");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusEqualTo(Integer value) {
            addCriterion("on_Line_Status =", value, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusNotEqualTo(Integer value) {
            addCriterion("on_Line_Status <>", value, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusGreaterThan(Integer value) {
            addCriterion("on_Line_Status >", value, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("on_Line_Status >=", value, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusLessThan(Integer value) {
            addCriterion("on_Line_Status <", value, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusLessThanOrEqualTo(Integer value) {
            addCriterion("on_Line_Status <=", value, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusIn(List<Integer> values) {
            addCriterion("on_Line_Status in", values, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusNotIn(List<Integer> values) {
            addCriterion("on_Line_Status not in", values, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusBetween(Integer value1, Integer value2) {
            addCriterion("on_Line_Status between", value1, value2, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("on_Line_Status not between", value1, value2, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andUserTypeIsNull() {
            addCriterion("user_type is null");
            return (Criteria) this;
        }

        public Criteria andUserTypeIsNotNull() {
            addCriterion("user_type is not null");
            return (Criteria) this;
        }

        public Criteria andUserTypeEqualTo(Integer value) {
            addCriterion("user_type =", value, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeNotEqualTo(Integer value) {
            addCriterion("user_type <>", value, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeGreaterThan(Integer value) {
            addCriterion("user_type >", value, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("user_type >=", value, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeLessThan(Integer value) {
            addCriterion("user_type <", value, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeLessThanOrEqualTo(Integer value) {
            addCriterion("user_type <=", value, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeIn(List<Integer> values) {
            addCriterion("user_type in", values, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeNotIn(List<Integer> values) {
            addCriterion("user_type not in", values, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeBetween(Integer value1, Integer value2) {
            addCriterion("user_type between", value1, value2, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("user_type not between", value1, value2, "userType");
            return (Criteria) this;
        }

        public Criteria andCreateByIdIsNull() {
            addCriterion("create_By_Id is null");
            return (Criteria) this;
        }

        public Criteria andCreateByIdIsNotNull() {
            addCriterion("create_By_Id is not null");
            return (Criteria) this;
        }

        public Criteria andCreateByIdEqualTo(Long value) {
            addCriterion("create_By_Id =", value, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdNotEqualTo(Long value) {
            addCriterion("create_By_Id <>", value, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdGreaterThan(Long value) {
            addCriterion("create_By_Id >", value, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdGreaterThanOrEqualTo(Long value) {
            addCriterion("create_By_Id >=", value, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdLessThan(Long value) {
            addCriterion("create_By_Id <", value, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdLessThanOrEqualTo(Long value) {
            addCriterion("create_By_Id <=", value, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdIn(List<Long> values) {
            addCriterion("create_By_Id in", values, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdNotIn(List<Long> values) {
            addCriterion("create_By_Id not in", values, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdBetween(Long value1, Long value2) {
            addCriterion("create_By_Id between", value1, value2, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdNotBetween(Long value1, Long value2) {
            addCriterion("create_By_Id not between", value1, value2, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByDateIsNull() {
            addCriterion("create_By_Date is null");
            return (Criteria) this;
        }

        public Criteria andCreateByDateIsNotNull() {
            addCriterion("create_By_Date is not null");
            return (Criteria) this;
        }

        public Criteria andCreateByDateEqualTo(Date value) {
            addCriterion("create_By_Date =", value, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateNotEqualTo(Date value) {
            addCriterion("create_By_Date <>", value, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateGreaterThan(Date value) {
            addCriterion("create_By_Date >", value, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateGreaterThanOrEqualTo(Date value) {
            addCriterion("create_By_Date >=", value, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateLessThan(Date value) {
            addCriterion("create_By_Date <", value, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateLessThanOrEqualTo(Date value) {
            addCriterion("create_By_Date <=", value, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateIn(List<Date> values) {
            addCriterion("create_By_Date in", values, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateNotIn(List<Date> values) {
            addCriterion("create_By_Date not in", values, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateBetween(Date value1, Date value2) {
            addCriterion("create_By_Date between", value1, value2, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateNotBetween(Date value1, Date value2) {
            addCriterion("create_By_Date not between", value1, value2, "createByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdIsNull() {
            addCriterion("update_by_id is null");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdIsNotNull() {
            addCriterion("update_by_id is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdEqualTo(Long value) {
            addCriterion("update_by_id =", value, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdNotEqualTo(Long value) {
            addCriterion("update_by_id <>", value, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdGreaterThan(Long value) {
            addCriterion("update_by_id >", value, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdGreaterThanOrEqualTo(Long value) {
            addCriterion("update_by_id >=", value, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdLessThan(Long value) {
            addCriterion("update_by_id <", value, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdLessThanOrEqualTo(Long value) {
            addCriterion("update_by_id <=", value, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdIn(List<Long> values) {
            addCriterion("update_by_id in", values, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdNotIn(List<Long> values) {
            addCriterion("update_by_id not in", values, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdBetween(Long value1, Long value2) {
            addCriterion("update_by_id between", value1, value2, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdNotBetween(Long value1, Long value2) {
            addCriterion("update_by_id not between", value1, value2, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateIsNull() {
            addCriterion("update_by_date is null");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateIsNotNull() {
            addCriterion("update_by_date is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateEqualTo(Date value) {
            addCriterion("update_by_date =", value, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateNotEqualTo(Date value) {
            addCriterion("update_by_date <>", value, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateGreaterThan(Date value) {
            addCriterion("update_by_date >", value, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateGreaterThanOrEqualTo(Date value) {
            addCriterion("update_by_date >=", value, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateLessThan(Date value) {
            addCriterion("update_by_date <", value, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateLessThanOrEqualTo(Date value) {
            addCriterion("update_by_date <=", value, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateIn(List<Date> values) {
            addCriterion("update_by_date in", values, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateNotIn(List<Date> values) {
            addCriterion("update_by_date not in", values, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateBetween(Date value1, Date value2) {
            addCriterion("update_by_date between", value1, value2, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateNotBetween(Date value1, Date value2) {
            addCriterion("update_by_date not between", value1, value2, "updateByDate");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}