package cn.zymx.webTM.web.services.impl;

import cn.zymx.webTM.web.dao.entity.User;
import cn.zymx.webTM.web.dao.mapper.UserMapper;
import cn.zymx.webTM.web.services.ITestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by zhuqiang on 2015/6/21 0021.
 */
@Service
public class TestServiceImpl implements ITestService{
    @Autowired
    private UserMapper userMapper;

    public List<User> findAllUser(){
        List<User> users = userMapper.selectByExample(null);
        return users;
    }
}
