package cn.zymx.webTM.web.services;

/**
 * Created by zhuqiang on 2015/7/1 0001.
 */
public interface IChatroomService {
}
