package cn.zymx.webTM.web.dao.entity;

import java.util.Date;

public class ChatroomMsgHstory {
    /** 聊天室id */
    private Long chatroomId;

    /** 消息内容 */
    private String msgBody;

    /** 用户头像 */
    private String icons;

    /** 用户昵称 */
    private String nickname;

    /** 服务器接受消息的时间 */
    private Date timeOfReception;

    /** 消息类型 */
    private Integer msgType;

    /** 用户类型 */
    private Integer userType;

    /** 用户id */
    private Long userId;

    private Long createById;

    private Date createByDate;

    private Long updateById;

    private Date updateByDate;

    /** 聊天室id */
    public Long getChatroomId() {
        return chatroomId;
    }

    public void setChatroomId(Long chatroomId) {
        this.chatroomId = chatroomId;
    }

    /** 消息内容 */
    public String getMsgBody() {
        return msgBody;
    }

    public void setMsgBody(String msgBody) {
        this.msgBody = msgBody == null ? null : msgBody.trim();
    }

    /** 用户头像 */
    public String getIcons() {
        return icons;
    }

    public void setIcons(String icons) {
        this.icons = icons == null ? null : icons.trim();
    }

    /** 用户昵称 */
    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname == null ? null : nickname.trim();
    }

    /** 服务器接受消息的时间 */
    public Date getTimeOfReception() {
        return timeOfReception;
    }

    public void setTimeOfReception(Date timeOfReception) {
        this.timeOfReception = timeOfReception;
    }

    /** 消息类型 */
    public Integer getMsgType() {
        return msgType;
    }

    public void setMsgType(Integer msgType) {
        this.msgType = msgType;
    }

    /** 用户类型 */
    public Integer getUserType() {
        return userType;
    }

    public void setUserType(Integer userType) {
        this.userType = userType;
    }

    /** 用户id */
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getCreateById() {
        return createById;
    }

    public void setCreateById(Long createById) {
        this.createById = createById;
    }

    public Date getCreateByDate() {
        return createByDate;
    }

    public void setCreateByDate(Date createByDate) {
        this.createByDate = createByDate;
    }

    public Long getUpdateById() {
        return updateById;
    }

    public void setUpdateById(Long updateById) {
        this.updateById = updateById;
    }

    public Date getUpdateByDate() {
        return updateByDate;
    }

    public void setUpdateByDate(Date updateByDate) {
        this.updateByDate = updateByDate;
    }
}