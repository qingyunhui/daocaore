package cn.zymx.webTM.web.dao.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ChatroomOnLineExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public ChatroomOnLineExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andChatroomIdIsNull() {
            addCriterion("Chatroom_Id is null");
            return (Criteria) this;
        }

        public Criteria andChatroomIdIsNotNull() {
            addCriterion("Chatroom_Id is not null");
            return (Criteria) this;
        }

        public Criteria andChatroomIdEqualTo(Long value) {
            addCriterion("Chatroom_Id =", value, "chatroomId");
            return (Criteria) this;
        }

        public Criteria andChatroomIdNotEqualTo(Long value) {
            addCriterion("Chatroom_Id <>", value, "chatroomId");
            return (Criteria) this;
        }

        public Criteria andChatroomIdGreaterThan(Long value) {
            addCriterion("Chatroom_Id >", value, "chatroomId");
            return (Criteria) this;
        }

        public Criteria andChatroomIdGreaterThanOrEqualTo(Long value) {
            addCriterion("Chatroom_Id >=", value, "chatroomId");
            return (Criteria) this;
        }

        public Criteria andChatroomIdLessThan(Long value) {
            addCriterion("Chatroom_Id <", value, "chatroomId");
            return (Criteria) this;
        }

        public Criteria andChatroomIdLessThanOrEqualTo(Long value) {
            addCriterion("Chatroom_Id <=", value, "chatroomId");
            return (Criteria) this;
        }

        public Criteria andChatroomIdIn(List<Long> values) {
            addCriterion("Chatroom_Id in", values, "chatroomId");
            return (Criteria) this;
        }

        public Criteria andChatroomIdNotIn(List<Long> values) {
            addCriterion("Chatroom_Id not in", values, "chatroomId");
            return (Criteria) this;
        }

        public Criteria andChatroomIdBetween(Long value1, Long value2) {
            addCriterion("Chatroom_Id between", value1, value2, "chatroomId");
            return (Criteria) this;
        }

        public Criteria andChatroomIdNotBetween(Long value1, Long value2) {
            addCriterion("Chatroom_Id not between", value1, value2, "chatroomId");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNull() {
            addCriterion("user_Id is null");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNotNull() {
            addCriterion("user_Id is not null");
            return (Criteria) this;
        }

        public Criteria andUserIdEqualTo(Long value) {
            addCriterion("user_Id =", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotEqualTo(Long value) {
            addCriterion("user_Id <>", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThan(Long value) {
            addCriterion("user_Id >", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("user_Id >=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThan(Long value) {
            addCriterion("user_Id <", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThanOrEqualTo(Long value) {
            addCriterion("user_Id <=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdIn(List<Long> values) {
            addCriterion("user_Id in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotIn(List<Long> values) {
            addCriterion("user_Id not in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdBetween(Long value1, Long value2) {
            addCriterion("user_Id between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotBetween(Long value1, Long value2) {
            addCriterion("user_Id not between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusIsNull() {
            addCriterion("on_Line_Status is null");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusIsNotNull() {
            addCriterion("on_Line_Status is not null");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusEqualTo(Integer value) {
            addCriterion("on_Line_Status =", value, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusNotEqualTo(Integer value) {
            addCriterion("on_Line_Status <>", value, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusGreaterThan(Integer value) {
            addCriterion("on_Line_Status >", value, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("on_Line_Status >=", value, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusLessThan(Integer value) {
            addCriterion("on_Line_Status <", value, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusLessThanOrEqualTo(Integer value) {
            addCriterion("on_Line_Status <=", value, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusIn(List<Integer> values) {
            addCriterion("on_Line_Status in", values, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusNotIn(List<Integer> values) {
            addCriterion("on_Line_Status not in", values, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusBetween(Integer value1, Integer value2) {
            addCriterion("on_Line_Status between", value1, value2, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andOnLineStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("on_Line_Status not between", value1, value2, "onLineStatus");
            return (Criteria) this;
        }

        public Criteria andTokenIsNull() {
            addCriterion("token is null");
            return (Criteria) this;
        }

        public Criteria andTokenIsNotNull() {
            addCriterion("token is not null");
            return (Criteria) this;
        }

        public Criteria andTokenEqualTo(String value) {
            addCriterion("token =", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenNotEqualTo(String value) {
            addCriterion("token <>", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenGreaterThan(String value) {
            addCriterion("token >", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenGreaterThanOrEqualTo(String value) {
            addCriterion("token >=", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenLessThan(String value) {
            addCriterion("token <", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenLessThanOrEqualTo(String value) {
            addCriterion("token <=", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenLike(String value) {
            addCriterion("token like", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenNotLike(String value) {
            addCriterion("token not like", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenIn(List<String> values) {
            addCriterion("token in", values, "token");
            return (Criteria) this;
        }

        public Criteria andTokenNotIn(List<String> values) {
            addCriterion("token not in", values, "token");
            return (Criteria) this;
        }

        public Criteria andTokenBetween(String value1, String value2) {
            addCriterion("token between", value1, value2, "token");
            return (Criteria) this;
        }

        public Criteria andTokenNotBetween(String value1, String value2) {
            addCriterion("token not between", value1, value2, "token");
            return (Criteria) this;
        }

        public Criteria andCreateByIdIsNull() {
            addCriterion("create_By_Id is null");
            return (Criteria) this;
        }

        public Criteria andCreateByIdIsNotNull() {
            addCriterion("create_By_Id is not null");
            return (Criteria) this;
        }

        public Criteria andCreateByIdEqualTo(Long value) {
            addCriterion("create_By_Id =", value, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdNotEqualTo(Long value) {
            addCriterion("create_By_Id <>", value, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdGreaterThan(Long value) {
            addCriterion("create_By_Id >", value, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdGreaterThanOrEqualTo(Long value) {
            addCriterion("create_By_Id >=", value, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdLessThan(Long value) {
            addCriterion("create_By_Id <", value, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdLessThanOrEqualTo(Long value) {
            addCriterion("create_By_Id <=", value, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdIn(List<Long> values) {
            addCriterion("create_By_Id in", values, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdNotIn(List<Long> values) {
            addCriterion("create_By_Id not in", values, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdBetween(Long value1, Long value2) {
            addCriterion("create_By_Id between", value1, value2, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByIdNotBetween(Long value1, Long value2) {
            addCriterion("create_By_Id not between", value1, value2, "createById");
            return (Criteria) this;
        }

        public Criteria andCreateByDateIsNull() {
            addCriterion("create_By_Date is null");
            return (Criteria) this;
        }

        public Criteria andCreateByDateIsNotNull() {
            addCriterion("create_By_Date is not null");
            return (Criteria) this;
        }

        public Criteria andCreateByDateEqualTo(Date value) {
            addCriterion("create_By_Date =", value, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateNotEqualTo(Date value) {
            addCriterion("create_By_Date <>", value, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateGreaterThan(Date value) {
            addCriterion("create_By_Date >", value, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateGreaterThanOrEqualTo(Date value) {
            addCriterion("create_By_Date >=", value, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateLessThan(Date value) {
            addCriterion("create_By_Date <", value, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateLessThanOrEqualTo(Date value) {
            addCriterion("create_By_Date <=", value, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateIn(List<Date> values) {
            addCriterion("create_By_Date in", values, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateNotIn(List<Date> values) {
            addCriterion("create_By_Date not in", values, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateBetween(Date value1, Date value2) {
            addCriterion("create_By_Date between", value1, value2, "createByDate");
            return (Criteria) this;
        }

        public Criteria andCreateByDateNotBetween(Date value1, Date value2) {
            addCriterion("create_By_Date not between", value1, value2, "createByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdIsNull() {
            addCriterion("update_by_id is null");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdIsNotNull() {
            addCriterion("update_by_id is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdEqualTo(Long value) {
            addCriterion("update_by_id =", value, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdNotEqualTo(Long value) {
            addCriterion("update_by_id <>", value, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdGreaterThan(Long value) {
            addCriterion("update_by_id >", value, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdGreaterThanOrEqualTo(Long value) {
            addCriterion("update_by_id >=", value, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdLessThan(Long value) {
            addCriterion("update_by_id <", value, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdLessThanOrEqualTo(Long value) {
            addCriterion("update_by_id <=", value, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdIn(List<Long> values) {
            addCriterion("update_by_id in", values, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdNotIn(List<Long> values) {
            addCriterion("update_by_id not in", values, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdBetween(Long value1, Long value2) {
            addCriterion("update_by_id between", value1, value2, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByIdNotBetween(Long value1, Long value2) {
            addCriterion("update_by_id not between", value1, value2, "updateById");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateIsNull() {
            addCriterion("update_by_date is null");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateIsNotNull() {
            addCriterion("update_by_date is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateEqualTo(Date value) {
            addCriterion("update_by_date =", value, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateNotEqualTo(Date value) {
            addCriterion("update_by_date <>", value, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateGreaterThan(Date value) {
            addCriterion("update_by_date >", value, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateGreaterThanOrEqualTo(Date value) {
            addCriterion("update_by_date >=", value, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateLessThan(Date value) {
            addCriterion("update_by_date <", value, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateLessThanOrEqualTo(Date value) {
            addCriterion("update_by_date <=", value, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateIn(List<Date> values) {
            addCriterion("update_by_date in", values, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateNotIn(List<Date> values) {
            addCriterion("update_by_date not in", values, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateBetween(Date value1, Date value2) {
            addCriterion("update_by_date between", value1, value2, "updateByDate");
            return (Criteria) this;
        }

        public Criteria andUpdateByDateNotBetween(Date value1, Date value2) {
            addCriterion("update_by_date not between", value1, value2, "updateByDate");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}