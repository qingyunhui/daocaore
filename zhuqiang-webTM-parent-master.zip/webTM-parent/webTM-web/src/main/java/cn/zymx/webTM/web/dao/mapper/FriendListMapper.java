package cn.zymx.webTM.web.dao.mapper;

import cn.zymx.webTM.web.dao.entity.FriendList;
import cn.zymx.webTM.web.dao.entity.FriendListExample;
import cn.zymx.webTM.web.dao.entity.FriendListKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface FriendListMapper {
    int countByExample(FriendListExample example);

    int deleteByExample(FriendListExample example);

    int deleteByPrimaryKey(FriendListKey key);

    int insert(FriendList record);

    int insertSelective(FriendList record);

    List<FriendList> selectByExample(FriendListExample example);

    FriendList selectByPrimaryKey(FriendListKey key);

    int updateByExampleSelective(@Param("record") FriendList record, @Param("example") FriendListExample example);

    int updateByExample(@Param("record") FriendList record, @Param("example") FriendListExample example);

    int updateByPrimaryKeySelective(FriendList record);

    int updateByPrimaryKey(FriendList record);
}