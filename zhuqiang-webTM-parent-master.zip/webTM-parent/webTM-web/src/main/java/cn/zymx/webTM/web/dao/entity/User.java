package cn.zymx.webTM.web.dao.entity;

import java.util.Date;

public class User {
    /** 用户id */
    private Long userId;

    /** 邮箱 */
    private String email;

    /** 昵称
             */
    private String nickname;

    /** 密码 */
    private String password;

    /** 头像 */
    private String icons;

    /** 在线状态 */
    private Integer onLineStatus;

    private Integer userType;

    private Long createById;

    private Date createByDate;

    private Long updateById;

    private Date updateByDate;

    /** 用户id */
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /** 邮箱 */
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    /** 昵称
             */
    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname == null ? null : nickname.trim();
    }

    /** 密码 */
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    /** 头像 */
    public String getIcons() {
        return icons;
    }

    public void setIcons(String icons) {
        this.icons = icons == null ? null : icons.trim();
    }

    /** 在线状态 */
    public Integer getOnLineStatus() {
        return onLineStatus;
    }

    public void setOnLineStatus(Integer onLineStatus) {
        this.onLineStatus = onLineStatus;
    }

    public Integer getUserType() {
        return userType;
    }

    public void setUserType(Integer userType) {
        this.userType = userType;
    }

    public Long getCreateById() {
        return createById;
    }

    public void setCreateById(Long createById) {
        this.createById = createById;
    }

    public Date getCreateByDate() {
        return createByDate;
    }

    public void setCreateByDate(Date createByDate) {
        this.createByDate = createByDate;
    }

    public Long getUpdateById() {
        return updateById;
    }

    public void setUpdateById(Long updateById) {
        this.updateById = updateById;
    }

    public Date getUpdateByDate() {
        return updateByDate;
    }

    public void setUpdateByDate(Date updateByDate) {
        this.updateByDate = updateByDate;
    }
}