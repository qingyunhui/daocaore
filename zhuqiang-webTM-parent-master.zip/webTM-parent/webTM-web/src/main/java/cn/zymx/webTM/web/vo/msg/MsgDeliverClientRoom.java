package cn.zymx.webTM.web.vo.msg;

import java.util.List;

/**
 * Created by zhuqiang on 2015/7/3 0003.
 */
public class MsgDeliverClientRoom  extends MsgDeliverClient {

}
