package cn.zymx.webTM.web.dao.mapper;

import cn.zymx.webTM.web.dao.entity.Chatroom;
import cn.zymx.webTM.web.dao.entity.ChatroomExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ChatroomMapper {
    int countByExample(ChatroomExample example);

    int deleteByExample(ChatroomExample example);

    int deleteByPrimaryKey(Long chatroomId);

    int insert(Chatroom record);

    int insertSelective(Chatroom record);

    List<Chatroom> selectByExample(ChatroomExample example);

    Chatroom selectByPrimaryKey(Long chatroomId);

    int updateByExampleSelective(@Param("record") Chatroom record, @Param("example") ChatroomExample example);

    int updateByExample(@Param("record") Chatroom record, @Param("example") ChatroomExample example);

    int updateByPrimaryKeySelective(Chatroom record);

    int updateByPrimaryKey(Chatroom record);
}