package cn.zymx.webTM.web.dao.mapper;

import cn.zymx.webTM.web.dao.entity.UserServiceList;
import cn.zymx.webTM.web.dao.entity.UserServiceListExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserServiceListMapper {
    int countByExample(UserServiceListExample example);

    int deleteByExample(UserServiceListExample example);

    int insert(UserServiceList record);

    int insertSelective(UserServiceList record);

    List<UserServiceList> selectByExample(UserServiceListExample example);

    int updateByExampleSelective(@Param("record") UserServiceList record, @Param("example") UserServiceListExample example);

    int updateByExample(@Param("record") UserServiceList record, @Param("example") UserServiceListExample example);
}