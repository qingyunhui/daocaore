﻿/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2015/6/30 星期二 21:25:40                       */
/*==============================================================*/


drop table if exists Chatroom;

drop table if exists Chatroom_Msg_hstory;

drop table if exists Chatroom_on_line;

drop table if exists friend_list;

drop table if exists user;

drop table if exists user_service_list;

/*==============================================================*/
/* Table: Chatroom                                              */
/*==============================================================*/
create table Chatroom
(
   Chatroom_id          int not null comment '聊天室id',
   user_Id              bigint not null comment '所属用户id',
   name                 varchar(32) comment '名称',
   intro                varchar(255) comment '简介',
   create_By_Id         bigint,
   create_By_Date       datetime,
   update_by_id         bigint,
   update_by_date       datetime,
   primary key (Chatroom_id)
);

alter table Chatroom comment '聊天室';

/*==============================================================*/
/* Table: Chatroom_Msg_hstory                                   */
/*==============================================================*/
create table Chatroom_Msg_hstory
(
   Chatroom_id          int comment '聊天室id',
   msg_body             varchar(512) comment '消息内容',
   icons                varchar(255) comment '用户头像',
   nickname             varchar(16) comment '用户昵称',
   `time_of _reception` datetime comment '服务器接受消息的时间',
   msg_Type             int comment '消息类型',
   user_type            int comment '用户类型',
   user_Id              bigint comment '用户id',
   create_By_Id         bigint,
   create_By_Date       datetime,
   update_by_id         bigint,
   update_by_date       datetime
);


alter table Chatroom_Msg_hstory comment '聊天室消息记录';

/*==============================================================*/
/* Table: Chatroom_on_line                                      */
/*==============================================================*/
create table Chatroom_on_line
(
   Chatroom_Id          int not null comment '聊天室id',
   user_Id              bigint not null comment '用户id',
   on_Line_Status       int comment '用户在线状态',
   token                varchar(32) comment '每个用户第一次进入聊天室就会生成一个token',
   create_By_Id         bigint,
   create_By_Date       datetime,
   update_by_id         bigint,
   update_by_date       datetime,
   primary key (Chatroom_Id, user_Id)
);

alter table Chatroom_on_line comment '聊天室在线列表，实时更新，不在的用户移除列表';

/*==============================================================*/
/* Table: friend_list                                           */
/*==============================================================*/
create table friend_list
(
   user_Id              bigint not null comment '用户id',
   friend_User_Id       bigint not null comment '好友id',
   create_By_Id         bigint,
   create_By_Date       datetime,
   update_by_id         bigint,
   update_by_date       datetime,
   primary key (user_Id, friend_User_Id)
);

alter table friend_list comment '好友列表';

/*==============================================================*/
/* Table: user                                                  */
/*==============================================================*/
create table user
(
   user_Id              bigint not null comment '用户id',
   email                varchar(32) comment '邮箱',
   nickname             varchar(16) comment '昵称
            ',
   password             varchar(32) not null comment '密码',
   Icons                varchar(255) comment '头像',
   on_Line_Status       int comment '在线状态',
   create_By_Id         bigint,
   create_By_Date       datetime,
   update_by_id         bigint,
   update_by_date       datetime,
   primary key (user_Id)
);

alter table user comment '用户表';

/*==============================================================*/
/* Table: user_service_list                                     */
/*==============================================================*/
create table user_service_list
(
   user_Id              bigint,
   service_id           int,
   service_type         char(10)
);

alter table Chatroom add constraint FK_Reference_5 foreign key (user_Id)
references user (user_Id) on delete restrict on update restrict;

alter table Chatroom_Msg_hstory add constraint FK_Reference_6 foreign key (Chatroom_id)
references Chatroom (Chatroom_id) on delete restrict on update restrict;

alter table Chatroom_on_line add constraint FK_Reference_3 foreign key (Chatroom_Id)
references Chatroom (Chatroom_id) on delete restrict on update restrict;

alter table Chatroom_on_line add constraint FK_Reference_4 foreign key (user_Id)
references user (user_Id) on delete restrict on update restrict;

alter table friend_list add constraint FK_Reference_1 foreign key (user_Id)
references user (user_Id) on delete restrict on update restrict;

alter table friend_list add constraint FK_Reference_2 foreign key (friend_User_Id)
references user (user_Id) on delete restrict on update restrict;

alter table user_service_list add constraint FK_Reference_7 foreign key (user_Id)
references user (user_Id) on delete restrict on update restrict;

