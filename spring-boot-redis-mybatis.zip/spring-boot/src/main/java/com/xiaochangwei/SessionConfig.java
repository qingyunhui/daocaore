package com.xiaochangwei;

import org.springframework.context.annotation.Configuration;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;

/**
 * @since 2017年2月28日 上午11:52:36
 * @author 肖昌伟	317409898@qq.com
 * @description 
 */
//@Configuration
//@EnableRedisHttpSession(maxInactiveIntervalInSeconds = 86400*30)
public class SessionConfig {

}
