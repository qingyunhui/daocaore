package com.xiaochangwei.vo;

import com.xiaochangwei.entity.User;

/**
 * @since 2017年2月7日 下午2:19:51
 * @author 肖昌伟 317409898@qq.com
 * @description
 */
public class UserParamVo extends User {

	private static final long serialVersionUID = 1359693330722882576L;

}
